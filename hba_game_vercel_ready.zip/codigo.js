function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('HBA Legacy')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/**
 * Valida e padroniza o nome escolhido na tela de boas-vindas.
 * O retorno pode ser usado pelo front-end sem provocar navegação ou reload.
 */
function prepararNovoLegado(nomeUsuario) {
  return {
    nomeTime: normalizarNomeTime_(nomeUsuario)
  };
}

function normalizarNomeTime_(nomeUsuario) {
  const nome = String(nomeUsuario || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 25);

  if (!nome) {
    throw new Error('Informe o nome da sua equipe.');
  }

  return nome;
}


/**
 * Valida o nome e devolve a primeira equipe do draft em uma única execução.
 * Isso evita que o front-end marque o jogo como iniciado antes do sorteio.
 */
function iniciarDraft(nomeUsuario, nomesExcluidos) {
  const nomeTime = normalizarNomeTime_(nomeUsuario);
  return {
    nomeTime: nomeTime,
    equipe: sortearEquipe(nomesExcluidos || [])
  };
}

/**
 * Retorna uma equipe histórica para a etapa de draft.
 * Jogadores já escolhidos pelo usuário são removidos das opções.
 */
function sortearEquipe(nomesExcluidos) {
  const excluidos = criarSetExcluidos_(nomesExcluidos);
  const equipesValidas = listarEquipesDraftValidas_(excluidos);

  if (!equipesValidas.length) {
    throw new Error('Não há mais jogadores disponíveis para o draft.');
  }

  return formatarEquipeDraft_(embaralhar_(equipesValidas)[0], excluidos);
}

/**
 * Rolagem gratuita "Próxima Equipe": sorteia outra entrada histórica sem repetir
 * exatamente a equipe e a temporada que acabaram de aparecer.
 */
function sortearProximaEquipe(nomesExcluidos, temporadaAtual, equipeAtual) {
  const excluidos = criarSetExcluidos_(nomesExcluidos);
  const temporadaReferencia = String(temporadaAtual || '');
  const equipeReferencia = String(equipeAtual || '');
  const equipesValidas = listarEquipesDraftValidas_(excluidos).filter(function(equipe) {
    return !(String(equipe.temporada) === temporadaReferencia && String(equipe.time) === equipeReferencia);
  });

  if (!equipesValidas.length) {
    throw new Error('Não há uma próxima equipe disponível para o draft.');
  }

  return formatarEquipeDraft_(embaralhar_(equipesValidas)[0], excluidos);
}

/**
 * Spin "Outra Temporada": sempre troca para uma temporada diferente da atual.
 */
function sortearOutraTemporada(nomesExcluidos, temporadaAtual) {
  const excluidos = criarSetExcluidos_(nomesExcluidos);
  const temporadaReferencia = String(temporadaAtual || '');
  const equipesValidas = listarEquipesDraftValidas_(excluidos).filter(function(equipe) {
    return String(equipe.temporada) !== temporadaReferencia;
  });

  if (!equipesValidas.length) {
    throw new Error('Não há outra temporada disponível com jogadores válidos para o draft.');
  }

  return formatarEquipeDraft_(embaralhar_(equipesValidas)[0], excluidos);
}

/**
 * Spin "Outra Equipe": mantém obrigatoriamente a temporada atual e troca a equipe.
 */
function sortearEquipeMesmaTemporada(nomesExcluidos, temporadaAtual, equipeAtual) {
  const excluidos = criarSetExcluidos_(nomesExcluidos);
  const temporadaReferencia = String(temporadaAtual || '');
  const equipeReferencia = String(equipeAtual || '');

  if (!temporadaReferencia) {
    throw new Error('A temporada atual não foi identificada.');
  }

  const equipesValidas = listarEquipesDraftValidas_(excluidos).filter(function(equipe) {
    return String(equipe.temporada) === temporadaReferencia && String(equipe.time) !== equipeReferencia;
  });

  if (!equipesValidas.length) {
    throw new Error('Não há outra equipe disponível nesta temporada com jogadores válidos para o draft.');
  }

  return formatarEquipeDraft_(embaralhar_(equipesValidas)[0], excluidos);
}

function criarSetExcluidos_(nomesExcluidos) {
  return new Set((nomesExcluidos || []).map(function(nome) { return String(nome); }));
}

function listarEquipesDraftValidas_(excluidos) {
  return BANCO_CONSOLIDADO_HBA.filter(function(equipe) {
    return Array.isArray(equipe.elenco) && equipe.elenco.some(function(jogador) {
      return !excluidos.has(String(jogador.nome));
    });
  });
}

function formatarEquipeDraft_(equipe, excluidos) {
  if (!equipe) throw new Error('Nenhuma equipe válida foi encontrada.');

  const jogadores = equipe.elenco
    .filter(function(jogador) { return !excluidos.has(String(jogador.nome)); })
    .map(function(jogador) {
      return {
        nome: jogador.nome,
        posicao: normalizarPosicao_(jogador.posicao),
        overall: Number(jogador.overall) || 82,
        overallBase: Number(jogador.overallBase) || Number(jogador.overall) || 82,
        ajusteTemporada: Number(jogador.ajusteTemporada) || 0
      };
    });

  if (!jogadores.length) {
    throw new Error('A equipe sorteada não possui jogadores disponíveis.');
  }

  const somaOvr = jogadores.reduce(function(total, jogador) {
    return total + jogador.overall;
  }, 0);

  const asset = obterAssetTime(equipe.time);

  return {
    time: equipe.time,
    temporada: String(equipe.temporada),
    conferencia: equipe.conferencia || asset.conferencia,
    logo: asset.logo,
    ovrEquipe: Math.round(somaOvr / jogadores.length),
    jogadores: jogadores
  };
}

/**
 * Monta uma liga com seis equipes: o time do usuário e cinco franquias aleatórias.
 * O calendário é um turno único, então todos jogam exatamente cinco partidas.
 */
function gerarLigaTemporada(nomeUsuario, rosterUsuario) {
  const nomeTimeUsuario = normalizarNomeTime_(nomeUsuario);
  const rosterLimpo = (rosterUsuario || []).map(function(jogador) {
    return {
      nome: String(jogador.nome || ''),
      posicao: normalizarPosicao_(jogador.posicao),
      overall: Number(jogador.overall) || 82,
      overallBase: Number(jogador.overallBase) || Number(jogador.overall) || 82,
      ajusteTemporada: Number(jogador.ajusteTemporada) || 0,
      temporada: String(jogador.temporada || ''),
      origem: String(jogador.origem || ''),
      funcao: String(jogador.funcao || 'RESERVA')
    };
  }).filter(function(jogador) { return jogador.nome; });

  if (rosterLimpo.length !== 4) {
    throw new Error('A equipe do jogador precisa ter exatamente quatro atletas.');
  }

  const nomesUsuario = new Set(rosterLimpo.map(function(jogador) { return jogador.nome; }));
  const conferenciaUsuario = Math.random() < 0.5 ? 'East' : 'West';
  const franquias = selecionarCincoFranquias_(conferenciaUsuario);
  const pool = criarPoolJogadores_(nomesUsuario);

  const overallUsuario = Math.round(rosterLimpo.reduce(function(total, jogador) {
    return total + jogador.overall;
  }, 0) / rosterLimpo.length);

  const equipes = [{
    id: 'USER',
    nome: nomeTimeUsuario,
    sigla: 'HBA',
    conferencia: conferenciaUsuario,
    logo: '',
    overall: overallUsuario,
    elenco: rosterLimpo,
    usuario: true,
    jogos: 0,
    vitorias: 0,
    derrotas: 0,
    pontosPro: 0,
    pontosContra: 0
  }];

  franquias.forEach(function(nomeFranquia, indice) {
    const asset = obterAssetTime(nomeFranquia);
    const elenco = gerarElencoCpu_(pool);
    const overall = Math.round(elenco.reduce(function(total, jogador) {
      return total + jogador.overall;
    }, 0) / elenco.length);

    equipes.push({
      id: 'CPU_' + (indice + 1),
      nome: nomeFranquia,
      sigla: asset.sigla,
      conferencia: asset.conferencia,
      logo: asset.logo,
      overall: overall,
      elenco: elenco,
      usuario: false,
      jogos: 0,
      vitorias: 0,
      derrotas: 0,
      pontosPro: 0,
      pontosContra: 0
    });
  });

  return {
    nomeUsuario: nomeTimeUsuario,
    equipes: equipes,
    calendario: gerarCalendarioTurnoUnico_(equipes.map(function(equipe) { return equipe.id; })),
    totalRodadas: 5,
    conferenciaUsuario: conferenciaUsuario
  };
}

/** Simula as três partidas de uma rodada da temporada regular. */
function simularRodadaRegular(jogos, equipes) {
  const porId = {};
  (equipes || []).forEach(function(equipe) { porId[equipe.id] = equipe; });

  return (jogos || []).map(function(jogo) {
    const casa = porId[jogo.casaId];
    const fora = porId[jogo.foraId];
    if (!casa || !fora) throw new Error('Uma equipe da rodada não foi encontrada.');

    const placar = simularPlacar_(casa.overall, fora.overall, 'REGULAR');
    return {
      casaId: casa.id,
      foraId: fora.id,
      pontosCasa: placar.pontosA,
      pontosFora: placar.pontosB,
      vencedorId: placar.pontosA > placar.pontosB ? casa.id : fora.id
    };
  });
}

/** Simula uma partida da série controlada pelo jogador. */
function simularPartidaEliminatoria(equipeUsuario, equipeAdversaria, fase) {
  if (!equipeUsuario || !equipeAdversaria) {
    throw new Error('Equipes inválidas para a partida eliminatória.');
  }

  const placar = simularPlacar_(equipeUsuario.overall, equipeAdversaria.overall, fase || 'PLAYOFFS');
  return {
    casaId: equipeUsuario.id,
    foraId: equipeAdversaria.id,
    pontosCasa: placar.pontosA,
    pontosFora: placar.pontosB,
    vencedorId: placar.pontosA > placar.pontosB ? equipeUsuario.id : equipeAdversaria.id
  };
}

/** Resolve uma série entre duas equipes controladas pela máquina. */
function simularSerieCpu(equipeA, equipeB, vitoriasNecessarias, fase) {
  const alvo = Number(vitoriasNecessarias) || 2;
  let vitoriasA = 0;
  let vitoriasB = 0;
  const jogos = [];

  while (vitoriasA < alvo && vitoriasB < alvo) {
    const placar = simularPlacar_(equipeA.overall, equipeB.overall, fase || 'PLAYOFFS');
    const vencedorId = placar.pontosA > placar.pontosB ? equipeA.id : equipeB.id;
    if (vencedorId === equipeA.id) vitoriasA++;
    else vitoriasB++;

    jogos.push({
      casaId: equipeA.id,
      foraId: equipeB.id,
      pontosCasa: placar.pontosA,
      pontosFora: placar.pontosB,
      vencedorId: vencedorId
    });
  }

  return {
    vencedorId: vitoriasA > vitoriasB ? equipeA.id : equipeB.id,
    vitoriasA: vitoriasA,
    vitoriasB: vitoriasB,
    jogos: jogos
  };
}

function selecionarCincoFranquias_(conferenciaUsuario) {
  const nomes = Object.keys(NBA_TEAM_ASSETS);
  const mesma = embaralhar_(nomes.filter(function(nome) {
    return NBA_TEAM_ASSETS[nome].conferencia === conferenciaUsuario;
  }));
  const oposta = embaralhar_(nomes.filter(function(nome) {
    return NBA_TEAM_ASSETS[nome].conferencia !== conferenciaUsuario;
  }));

  // A liga sempre tem três equipes por conferência:
  // usuário + duas franquias na sua conferência e três na conferência oposta.
  // Assim, o usuário pode realmente ser eliminado ainda na temporada regular.
  return embaralhar_([
    mesma[0], mesma[1],
    oposta[0], oposta[1], oposta[2]
  ]);
}

function criarPoolJogadores_(nomesExcluidos) {
  const melhoresPorNome = {};

  BANCO_CONSOLIDADO_HBA.forEach(function(equipe) {
    equipe.elenco.forEach(function(jogador) {
      if (nomesExcluidos.has(jogador.nome)) return;

      const candidato = {
        nome: jogador.nome,
        posicao: normalizarPosicao_(jogador.posicao),
        overall: Number(jogador.overall) || 82
      };

      if (!melhoresPorNome[candidato.nome] || candidato.overall > melhoresPorNome[candidato.nome].overall) {
        melhoresPorNome[candidato.nome] = candidato;
      }
    });
  });

  return embaralhar_(Object.keys(melhoresPorNome).map(function(nome) {
    return melhoresPorNome[nome];
  }));
}

/**
 * Monta um elenco de CPU competitivo e equilibrado.
 *
 * Perfil desejado por equipe:
 * - 1 estrela / muito bom: 94 a 95
 * - 1 jogador bom: 91 a 93
 * - 1 jogador médio: 88 a 90
 * - 1 peça fraca: 82 a 87
 *
 * A combinação final procura uma média entre 89 e 91. As faixas são relativas
 * ao banco histórico: o jogador "fraco" ainda pode ser útil, mas cria uma
 * vulnerabilidade real para impedir que todos os quatro atletas sejam estrelas.
 */
function gerarElencoCpu_(pool) {
  if (!pool || pool.length < 4) {
    throw new Error('O banco não possui jogadores suficientes para gerar os adversários.');
  }

  const slotsTitulares = [
    { nome: 'ARMADOR', posicoes: ['PG', 'SG'] },
    { nome: 'WING', posicoes: ['SF', 'PF'] },
    { nome: 'BIG', posicoes: ['PF', 'C'] }
  ];

  const perfisTitulares = [
    { nome: 'MUITO BOM', minimo: 94, maximo: 95, alvo: 95 },
    { nome: 'BOM', minimo: 91, maximo: 93, alvo: 92 },
    { nome: 'MÉDIO', minimo: 88, maximo: 90, alvo: 89 }
  ];

  const todasPosicoes = ['PG', 'SG', 'SF', 'PF', 'C'];
  const alvoMedia = 89 + Math.floor(Math.random() * 3); // 89, 90 ou 91
  let melhorFormacao = null;
  let melhorPontuacao = Infinity;

  // Testa diversas combinações sem retirar atletas do pool original.
  // No fim, somente a melhor formação consome os jogadores escolhidos.
  for (let tentativa = 0; tentativa < 60; tentativa++) {
    const disponiveis = pool.slice();
    const ordemSlots = embaralhar_(slotsTitulares.slice());
    const formacao = [];
    let falhou = false;

    for (let i = 0; i < perfisTitulares.length; i++) {
      const perfil = perfisTitulares[i];
      const slot = ordemSlots[i];
      const jogador = selecionarJogadorCpu_(
        disponiveis,
        slot.posicoes,
        perfil.minimo,
        perfil.maximo,
        perfil.alvo
      );

      if (!jogador) {
        falhou = true;
        break;
      }

      removerJogadorDoPool_(disponiveis, jogador.nome);
      formacao.push({
        nome: jogador.nome,
        posicao: jogador.posicao,
        overall: jogador.overall,
        funcao: slot.nome,
        nivelCpu: perfil.nome
      });
    }

    if (falhou || formacao.length !== 3) continue;

    const somaTitulares = formacao.reduce(function(total, jogador) {
      return total + jogador.overall;
    }, 0);

    // O reserva é selecionado por último e funciona como contrapeso da equipe.
    const alvoReserva = limitarNumero_((alvoMedia * 4) - somaTitulares, 82, 87);
    const reserva = selecionarJogadorCpu_(
      disponiveis,
      todasPosicoes,
      82,
      87,
      alvoReserva
    );

    if (!reserva) continue;

    formacao.push({
      nome: reserva.nome,
      posicao: reserva.posicao,
      overall: reserva.overall,
      funcao: '4th MAN',
      nivelCpu: 'FRACO'
    });

    const media = formacao.reduce(function(total, jogador) {
      return total + jogador.overall;
    }, 0) / 4;

    // Prioridade absoluta: ficar dentro da faixa de desafio pedida.
    // Depois, aproximar-se da média-alvo sorteada para diferenciar as equipes.
    const foraDaFaixa = media < 89 || media > 91;
    const distanciaMedia = Math.abs(media - alvoMedia);
    const distanciaPerfis = formacao.reduce(function(total, jogador) {
      const alvo = jogador.nivelCpu === 'MUITO BOM' ? 95
        : jogador.nivelCpu === 'BOM' ? 92
        : jogador.nivelCpu === 'MÉDIO' ? 89
        : alvoReserva;
      return total + Math.abs(jogador.overall - alvo);
    }, 0);

    const pontuacao = (foraDaFaixa ? 1000 : 0)
      + (distanciaMedia * 100)
      + (distanciaPerfis * 4)
      + Math.random();

    if (pontuacao < melhorPontuacao) {
      melhorPontuacao = pontuacao;
      melhorFormacao = formacao;
    }
  }

  // Fallback defensivo para bancos muito reduzidos ou desfalcados pelo draft.
  if (!melhorFormacao) {
    return gerarElencoCpuFallback_(pool);
  }

  return melhorFormacao.map(function(escolhido) {
    const indice = pool.findIndex(function(jogador) {
      return jogador.nome === escolhido.nome;
    });

    if (indice < 0) {
      throw new Error('Um jogador selecionado para a CPU não foi encontrado no pool.');
    }

    const jogador = pool.splice(indice, 1)[0];
    jogador.funcao = escolhido.funcao;
    jogador.nivelCpu = escolhido.nivelCpu;
    return jogador;
  });
}

/** Seleciona um jogador elegível, priorizando a faixa e o overall-alvo. */
function selecionarJogadorCpu_(pool, posicoes, minimo, maximo, alvo) {
  const elegiveis = pool.filter(function(jogador) {
    return posicoes.indexOf(jogador.posicao) !== -1;
  });

  if (!elegiveis.length) return null;

  const dentroDaFaixa = elegiveis.filter(function(jogador) {
    return jogador.overall >= minimo && jogador.overall <= maximo;
  });

  // Caso o usuário já tenha escolhido várias estrelas, a CPU utiliza o atleta
  // elegível mais próximo da faixa, em vez de falhar ao montar a equipe.
  const candidatos = (dentroDaFaixa.length ? dentroDaFaixa : elegiveis)
    .slice()
    .sort(function(a, b) {
      const distanciaA = Math.abs(a.overall - alvo);
      const distanciaB = Math.abs(b.overall - alvo);
      if (distanciaA !== distanciaB) return distanciaA - distanciaB;
      return b.overall - a.overall;
    });

  // Sorteio entre os melhores encaixes evita elencos idênticos em toda partida.
  const limite = Math.min(5, candidatos.length);
  return candidatos[Math.floor(Math.random() * limite)];
}

function removerJogadorDoPool_(pool, nomeJogador) {
  const indice = pool.findIndex(function(jogador) {
    return jogador.nome === nomeJogador;
  });
  if (indice >= 0) pool.splice(indice, 1);
}

function limitarNumero_(valor, minimo, maximo) {
  return Math.max(minimo, Math.min(maximo, Number(valor) || minimo));
}

/** Mantém o jogo funcional mesmo se o banco disponível estiver muito reduzido. */
function gerarElencoCpuFallback_(pool) {
  const funcoes = [
    { nome: 'ARMADOR', posicoes: ['PG', 'SG'] },
    { nome: 'WING', posicoes: ['SF', 'PF'] },
    { nome: 'BIG', posicoes: ['PF', 'C'] }
  ];

  const elenco = funcoes.map(function(funcao) {
    const jogador = retirarJogadorPorPosicao_(pool, funcao.posicoes);
    jogador.funcao = funcao.nome;
    jogador.nivelCpu = 'FALLBACK';
    return jogador;
  });

  if (!pool.length) {
    throw new Error('O banco não possui jogadores suficientes para gerar os adversários.');
  }

  const reserva = pool.shift();
  reserva.funcao = '4th MAN';
  reserva.nivelCpu = 'FALLBACK';
  elenco.push(reserva);
  return elenco;
}

function retirarJogadorPorPosicao_(pool, posicoes) {
  let indice = pool.findIndex(function(jogador) {
    return posicoes.indexOf(jogador.posicao) !== -1;
  });
  if (indice < 0) indice = 0;
  if (!pool[indice]) throw new Error('O banco não possui jogadores suficientes para montar os elencos.');
  return pool.splice(indice, 1)[0];
}

function gerarCalendarioTurnoUnico_(ids) {
  const rotacao = ids.slice();
  const total = rotacao.length;
  const rodadas = [];

  for (let rodada = 0; rodada < total - 1; rodada++) {
    const jogos = [];
    for (let i = 0; i < total / 2; i++) {
      let casaId = rotacao[i];
      let foraId = rotacao[total - 1 - i];
      if ((rodada + i) % 2 === 1) {
        const temporario = casaId;
        casaId = foraId;
        foraId = temporario;
      }
      jogos.push({ casaId: casaId, foraId: foraId });
    }
    rodadas.push({ numero: rodada + 1, jogos: jogos });

    const ultimo = rotacao.pop();
    rotacao.splice(1, 0, ultimo);
  }

  return rodadas;
}

function simularPlacar_(overallA, overallB, fase) {
  const pesoFase = fase === 'FINALS' ? 1.12 : fase === 'PLAYOFFS' ? 1.06 : 1;
  const variacaoA = Math.random() * 18 - 9;
  const variacaoB = Math.random() * 18 - 9;

  let pontosA = Math.round(68 + ((Number(overallA) - 75) * 2.15 * pesoFase) + variacaoA);
  let pontosB = Math.round(68 + ((Number(overallB) - 75) * 2.15 * pesoFase) + variacaoB);

  pontosA = Math.max(55, Math.min(125, pontosA));
  pontosB = Math.max(55, Math.min(125, pontosB));

  if (pontosA === pontosB) {
    if (Math.random() < 0.5) pontosA++;
    else pontosB++;
  }

  return { pontosA: pontosA, pontosB: pontosB };
}

function normalizarPosicao_(posicao) {
  const valor = String(posicao || '').toUpperCase();
  return ['PG', 'SG', 'SF', 'PF', 'C'].indexOf(valor) !== -1 ? valor : 'SF';
}

function embaralhar_(lista) {
  for (let i = lista.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temporario = lista[i];
    lista[i] = lista[j];
    lista[j] = temporario;
  }
  return lista;
}
